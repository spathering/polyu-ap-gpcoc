# LEGAL MANIFEST & ATTRIBUTION
**System:** Mausritter
**Module:** Masterwork Export - neural_link_export
**Publisher:** GM-Copilot Studios
**License:** Open RPG Creative (ORC) License / CC-BY 4.0

### MASTERWORK VERIFICATION SEAL
This Virtual Tabletop module was generated using deterministic data-extraction (Lean 4/OpenCV). 
It contains ZERO generative AI text, imagery, or hallucinated mechanics. All numerical invariants 
have been structurally verified.

### TRADE DRESS ISOLATION
No proprietary publisher trade dress, logos, or restricted entity names are included in this data payload. 
This is a third-party structural conversion built strictly from authorized SRD/Open mechanics.
